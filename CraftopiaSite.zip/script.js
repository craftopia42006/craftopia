
console.log('Craftopia site loaded.');
